package com.cognizant.composite_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompositeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
