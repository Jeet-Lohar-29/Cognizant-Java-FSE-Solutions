package com.cognizant.hibernate_annotations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateAnnotationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
